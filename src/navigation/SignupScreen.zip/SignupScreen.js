





import React, { Component,useState, useEffect } from 'react';
import { StatusBar } from 'react-native';
import {
  SafeAreaView,
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ImageBackground,
  Image,
  Button,
  Dimensions,
  ToastAndroid
} from 'react-native';
import MapView, {PROVIDER_GOOGLE} from 'react-native-maps';
import auth from '@react-native-firebase/auth';
import { GoogleSignin } from '@react-native-google-signin/google-signin';

const win = Dimensions.get('window');

import {NavigationService} from '../common';


async function onGoogleButtonPress() {

  console.log('start signup');

  const { idToken } = await GoogleSignin.signIn();
  console.log(idToken);

  const googleCredential = auth.GoogleAuthProvider.credential(idToken);
  const credentialPromise = auth().signInWithCredential(googleCredential);
  credentialPromise.then((credential) => {
    console.log(credential.additionalUserInfo.profile.email);
    checkLogin1(credential.additionalUserInfo.profile.email);
  });
}

checkLogin1 = async(check_email) => {
  console.log('check login1');
  console.log(check_email);
      const data1 = { email: check_email};

        return await fetch('http://175.125.94.194:1302' + '/api/chat/checkLogin', {
          method: 'post',
          body: JSON.stringify(data1),
          'headers': {
              'Content-Type': 'application/json',
            },
        })
          .then((response) => {
            if (response.status === 200) {
              return response.json();
            } else if (response.status === 404) {
              console.log('Unable to locate location');
            } else {
              throw 'something went wrong';
            }
          })
          .then((responseJson) => {
                console.log(responseJson);
                console.log(responseJson.status);
                if(responseJson.status == 1)
                {
                  ToastAndroid.show('이미 등록된 회원입니다', ToastAndroid.SHORT);
                }
                else
                {
                  //check this later to go its page
                  NavigationService.navigate('AddUserScreen', {
                    screen: 'AddUserScreen',
                    info: 'information',
                    email: check_email
                  });
                }

                  })
          .catch((error) => {
            console.log(error.toString());
          });
};

function SignupScreen(){
    
  const [location, setLocation] = useState({latitude: 37.557536061234515, longitude: 126.98504279658052});
  const [show, setShow] = useState(true);
  const [locations, setLocationData] = useState([]);

  console.log("111==============" + locations);
  
  const showConfirmDialog = () => {
    return Alert.alert(
      "로그인이 필요한 서비스입니다",
      "로그인하시겠어요?",
      [
        // The "Yes" button
        {
          text: "네",
          onPress: () => {
            NavigationService.navigate('LoginScreen', {
              screen: 'LoginScreen',
              info: 'information'
            })
          },
        },
        // The "No" button
        // Does nothing but dismiss the dialog when tapped
        {
          text: "아니",
        },
      ]
    );
  };

  function showDetail()
  {
    setShow(false);
    console.log(show);
  }

  async function getData() { 
    
    return await fetch('http://175.125.94.194:1302' + '/api/chat/getPetPlaces', {
        method: 'post',
        'headers': {
            'Content-Type': 'application/json',
          },
      })
        .then((response) => {
          if (response.status === 200) {
            return response.json();
          } else if (response.status === 404) {
            console.log('Unable to locate location');
          } else {
            throw 'something went wrong';
          }
        })
        .then((responseJson) => {
              console.log(responseJson.info);
              setLocationData(responseJson.info);
              console.log(show);
              console.log("1111==============" + locations);

                })
        .catch((error) => {
          console.log(error.toString());
        });
  }

  useEffect(() => {

    //check this later(현재 위치에 따라서 변하도록)

    console.log("2Signup==============");
    
    GoogleSignin.configure({
      webClientId:
        '132293262133-7v0k53iu41a1g66h9hgb79ok1gsplfnk.apps.googleusercontent.com',
      offlineAccess: true,
      forceCodeForRefreshToken: true,
      accountName: '',
    });

  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.card}>
        
        <View style={styles.menuBgImage}>
          <Text style={styles.appTitle}></Text>
        </View>

        <ScrollView style={styles.containerSearch}>
            
            <TouchableOpacity onPress={()=>onGoogleButtonPress()}>
                <Image source={require('./assets/google.png')}  style={styles.menuItem2} />
            </TouchableOpacity>

            <TouchableOpacity onPress={()=>NavigationService.navigate('AddUserScreen', {
                      screen: 'AddUserScreen',
                      info: 'information'
                  })}>
                <Image source={require('./assets/facebook.png')}  style={styles.menuItem2} />
            </TouchableOpacity>

            <TouchableOpacity onPress={()=>NavigationService.navigate('AddUserScreen', {
                      screen: 'AddUserScreen',
                      info: 'information'
                  })}>
                <Image source={require('./assets/kakao.png')}  style={styles.menuItem2} />
            </TouchableOpacity>

            <TouchableOpacity onPress={()=>NavigationService.navigate('AddUserScreen', {
                      screen: 'AddUserScreen',
                      info: 'information'
                  })}>
                <Image source={require('./assets/apple.png')}  style={styles.menuItem2} />
            </TouchableOpacity>


                    <View style={{flexDirection: 'row'}}>
                      <Text style={styles.appTitle1}>이미 가입하셨는가요</Text>
                      <TouchableOpacity onPress={()=>NavigationService.navigate('LoginScreen', {
                              screen: 'LoginScreen',
                              info: 'information'
                          })}>
                        <Image source={require('./assets/login.png')}  style={styles.menuItem22} />
                      </TouchableOpacity>
                    </View>

        </ScrollView>
        
      </View>
    </SafeAreaView>
  );
}



const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  appTitle: {
    color: '#000',
    fontFamily: 'GodoM',
    fontSize: 10,
    fontWeight: 'bold',
    marginTop: 30,
    marginBottom: 0,
    fontWeight: '300',
    textAlign: 'left',
    backgroundColor: '#ffffff',
  },
  appTitle1: {
    color: '#000',
    fontFamily: 'GodoM',
    fontSize: 10,
    fontWeight: 'bold',
    marginTop: 230,
    marginLeft: 0.22 * win.width,
    marginBottom: 0,
    fontWeight: '300',
    textAlign: 'center',
    backgroundColor: '#ffffff',
  },
  card: {
    backgroundColor: '#ffffff',
    flex: 1,
    borderTopLeftRadius: 10, // to provide rounded corners
    borderTopRightRadius: 10, // to provide rounded corners
    marginLeft: 0,
    marginRight: 0,
  },
  input: {
    flex : 0.1,
    padding: 5,
    borderBottomColor: '#bbb',
    borderBottomWidth: 1,
    fontFamily: 'GodoM',
    fontSize: 14,
    marginLeft: 10,
    marginRight: 10,
    textAlignVertical: "bottom",
  },
  containerMenu: {
    flex : (169 / 751) * win.width / win.height,
  },
  containerSearch: {
    flex : 1,
    marginLeft: 10,
    marginRight: 10,
  },
  menuBgImage: {
    width : win.width,
    height : (450 / 751) * win.width,
    flexDirection: 'row',
  },
  menuItem1: {
    width : (1 / 10) * win.width,
    height : (1 / 15) * win.width,
    marginLeft : (30 / 751) * win.width,
    marginTop : 30,
  },
  menuItemTxt1: {
    width : (75 / 751) * win.width,
    height : (75 / 751) * win.width,
    marginLeft : (40 / 751) * win.width,
    marginTop : (10 / 751) * win.width,
    fontSize: 8,
    textAlign: 'center'
  },
  menuItemTxt2: {
    width : (75 / 751) * win.width,
    height : (75 / 751) * win.width,
    marginLeft : (75 / 751) * win.width,
    marginTop : (10 / 751) * win.width,
    fontSize: 8,
    textAlign: 'center'
  },
  menuItem2: {
    width : 0.6 * win.width,
    height : 0.1 * win.width,
    marginLeft : 0.2 * win.width,
    marginTop : (10 / 751) * win.width,
  },
  menuItem22: {
    width : 0.21 * win.width,
    height : 0.07 * win.width,
    marginLeft : 2,
    marginTop : 223,
  },

  menuItem23: {
    flexDirection: 'row',
  },
});


export default SignupScreen;  