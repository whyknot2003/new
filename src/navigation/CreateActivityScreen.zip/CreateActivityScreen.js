import React, { Component } from 'react';
import { StatusBar } from 'react-native';
import {
  SafeAreaView,
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ImageBackground,
  Image,
  Button,
  Dimensions,
} from 'react-native';
import MapView, {PROVIDER_GOOGLE} from 'react-native-maps';
import * as ImagePicker from "react-native-image-picker"

const win = Dimensions.get('window');
import {NavigationService} from '../common';

class CreateActivityScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
          filepath: {
            data: '',
            uri: ''
          },
          fileData: '',
          fileUri: '',
          ac_name: '',
          ac_vil: '',
          ac_num: '',
          ac_price: '',
          ac_cat: '',
          ac_intro: '',
          ac_careful: '',
          ac_right: ''
        }
    }

    getBlobSize = async () => {
  
      const response = await fetch(this.state.fileUri);
      const blob = await response.blob();

      return blob;
    };

    createAct = async() => {
      console.log(this.state.ac_name + this.state.ac_vil + this.state.ac_num + this.state.ac_price + this.state.ac_cat
        + this.state.ac_intro + this.state.ac_careful + this.state.ac_right);
      
        const blob = this.getBlobSize();

        var blob_data = {
          uri: this.state.fileUri,
          name: 'image.png',
          type: 'image/png',
        };

        console.log(blob_data);

        var formData = new FormData();

        const data1 = { ac_name: this.state.ac_name,
                        ac_vil: this.state.ac_vil,
                        ac_num: this.state.ac_num,
                        ac_price: this.state.ac_price,
                        ac_cat: this.state.ac_cat,
                        ac_intro: this.state.ac_intro,
                        ac_careful: this.state.ac_careful,
                        ac_right: this.state.ac_right,
                        img: blob_data,
                        creator_id: 0};

      var formBody = [];
      for (var property in data1) {
        var encodedKey = encodeURIComponent(property);
        var encodedValue = encodeURIComponent(data1[property]);
        formBody.push(encodedKey + "=" + encodedValue);
      }

      formBody = formBody.join("&");

        return await fetch('http://175.125.94.194:1302' + '/api/chat/AddPetActivities', {
          method: 'post',
          body: formBody,
          'headers': {
              'Accept': 'application/json',
              'Content-Type': 'application/x-www-form-urlencoded'
            },
        })
          .then((response) => {
            if (response.status === 200) {
              return response.json();
            } else if (response.status === 404) {
              //ToastAndroid.show('Unable to locate location', ToastAndroid.SHORT);
              console.log('Unable to locate location');
            } else {
              throw 'something went wrong';
            }
          })
          .then((responseJson) => {
                console.log(responseJson);
                
                  })
          .catch((error) => {
            //ToastAndroid.show(error.toString(), ToastAndroid.SHORT);
            console.log(error.toString());
          });

    };

    selectFile = () => {
      
      ImagePicker.launchImageLibrary(
        {
          mediaType: 'photo',
          includeBase64: false,
          maxHeight: 200,
          maxWidth: 200,
        },
        (res) => {
          console.log('Response = ', res);
          if (res.didCancel) {
            console.log('User cancelled image picker');
          } else if (res.error) {
            console.log('ImagePicker Error: ', res.error);
          } else if (res.customButton) {
            console.log('User tapped custom button: ', res.customButton);
            alert(res.customButton);
          } else {

            console.log('Response = ', res.assets[0]);
            console.log('res uri : ' + res.assets[0].uri);


            this.setState({
              filePath: res,
              fileUri: res.assets[0].uri
            });

          }
        },
      )
  
    };

    renderFileUri() {
      if (this.state.fileUri) {
        console.log('file uri : ' + this.state.fileUri);
        return <Image
          source={{ uri: this.state.fileUri }}
          style={styles.avatar}
        />
      } else {
        console.log('no avatar : ' + this.state.fileUri);
        return <Image
          source={require('./assets/no_avatar.png')}
          style={styles.avatar}
        />
      }
    }

    render() {
        return (
            <SafeAreaView style={styles.container}>
              <View style={styles.card}>
                
                <View style={styles.menuBgImage}>
                    <TouchableOpacity onPress={()=> NavigationService.back()}>
                        <Image source={require('./assets/back.png')}  style={styles.menuItem1} />
                    </TouchableOpacity>
                  <Text style={styles.appTitle}>액티비티 개설하기</Text>
                </View>
        
                <ScrollView style={styles.containerSearch}>

                    <TouchableOpacity onPress={this.selectFile}>
                        {/*<Image source={require('./assets/no_avatar.png')}  style={styles.avatar} />*/}
                        {this.renderFileUri()}
                    </TouchableOpacity>

                    <View>
                      <Text style={styles.appTitle}>액티비티 제목</Text>
                      <TextInput style={styles.input} onChangeText={(value) => this.setState({ac_name: value})} placeholder="액티비티 제목 입력" />
                    </View>
                    <View>
                      <Text style={styles.appTitle}>액티비티 동네</Text>
                      <TextInput style={styles.input} onChangeText={(value) => this.setState({ac_vil: value})}  placeholder="액티비티 동네 입력" />
                    </View>
                    <View>
                      <Text style={styles.appTitle}>운영인원</Text>
                      <TextInput style={styles.input} onChangeText={(value) => this.setState({ac_num: value})}  placeholder="최소인원 입력" />
                    </View>
                    <View>
                      <Text style={styles.appTitle}>가격</Text>
                      <TextInput style={styles.input} onChangeText={(value) => this.setState({ac_price: value})}  placeholder="가격 입력" />
                    </View>
                    <View>
                      <Text style={styles.appTitle}>카테고리</Text>
                      <TextInput style={styles.input} onChangeText={(value) => this.setState({ac_cat: value})}  placeholder="카테고리 선택" />
                    </View>
                    <View>
                      <Text style={styles.appTitle}>액티비티 소개</Text>
                      <TextInput style={styles.input} onChangeText={(value) => this.setState({ac_intro: value})}  placeholder="액티비티 소개 내용 본문 입력" />
                    </View>
                    <View>
                      <Text style={styles.appTitle}>유의 사항(선택)</Text>
                      <TextInput style={styles.input} onChangeText={(value) => this.setState({ac_careful: value})}  placeholder="유의 사항 본문 입력" />
                    </View>
                    <View>
                      <Text style={styles.appTitle}>관련 자격증(선택)</Text>
                      <Text style={styles.appTitle1}>관련 자격증을 첨부할 시,</Text>
                      <Text style={styles.appTitle1}>심사후 펫타임 인증마크가 부여됩니다</Text>
                      <TextInput style={styles.input} onChangeText={(value) => this.setState({ac_right: value})}  placeholder="자격증 추가하기" />
                    </View>
                    <View style={styles.menuBgImage}>
                      <TouchableOpacity onPress={this.createAct}>
                          <Image source={require('./assets/finish.png')}  style={styles.menuItem2} />
                      </TouchableOpacity>
                    </View>

                </ScrollView>
                
              </View>
            </SafeAreaView>
          );
    }
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fffcf7',
    },
    appTitle: {
      color: '#000',
      fontSize: 18,
      fontWeight: 'bold',
      marginTop: 30,
      marginBottom: 0,
      fontWeight: '300',
      textAlign: 'left',
      backgroundColor: '#fffcf7',
    },
    appTitle1: {
      color: '#000',
      fontSize: 14,
      fontWeight: 'bold',
      marginTop: 10,
      marginBottom: 0,
      fontWeight: '300',
      textAlign: 'left',
      backgroundColor: '#fffcf7',
    },
    card: {
      backgroundColor: '#fffcf7',
      flex: 1,
      borderTopLeftRadius: 10, // to provide rounded corners
      borderTopRightRadius: 10, // to provide rounded corners
      marginLeft: 0,
      marginRight: 0,
    },
    input: {
      flex : 0.1,
      padding: 5,
      borderBottomColor: '#bbb',
      borderBottomWidth: 1,
      fontSize: 14,
      marginLeft: 10,
      marginRight: 10,
      textAlignVertical: "bottom",
    },
    containerMenu: {
      flex : (169 / 751) * win.width / win.height,
    },
    containerSearch: {
      flex : 1,
      marginLeft: 10,
      marginRight: 10,
    },
    menuBgImage: {
      width : win.width,
      height : (169 / 751) * win.width,
      flexDirection: 'row',
    },
    menuItem1: {
      width : (1 / 10) * win.width,
      height : (1 / 15) * win.width,
      marginLeft : (30 / 751) * win.width,
      marginTop : 30,
    },
    menuItem2: {
      width : (1 / 3) * win.width,
      height : (1 / 15) * win.width,
      marginLeft : (1 / 3) * win.width - 10,
      marginTop : (70 / 751) * win.width,
    },
    avatar: {
      width : (1 / 2) * win.width - 10,
      height : (1 / 2) * win.width,
      marginLeft : (1 / 4) * win.width,
      marginTop : (50 / 751) * win.width,
    },
  });

export default CreateActivityScreen;  